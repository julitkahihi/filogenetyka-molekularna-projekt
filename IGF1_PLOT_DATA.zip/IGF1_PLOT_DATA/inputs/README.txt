species.tsv              planned taxa with clade groups (76, core=60, extra=16)
body_mass_kg.tsv         47 provisional estimates; edit/replace using literature measurements
                         species,mass_kg[,mass_source] columns, tab-separated
                         Values are kg. They are illustrative, not verified measurements.
genome_accessions.tsv    optional accession overrides (assembly accessions GCF_/GCA_)
